package hu.ait.tictactoe.view

import android.content.Context
import android.util.AttributeSet
import android.view.View

class TicTacToeView(context: Context?, attrs: AttributeSet?) : View(context, attrs) {


}
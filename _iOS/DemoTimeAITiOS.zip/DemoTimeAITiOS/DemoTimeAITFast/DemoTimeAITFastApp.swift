//
//  DemoTimeAITFastApp.swift
//  DemoTimeAITFast
//
//  Created by Peter Ekler on 05/02/2024.
//

import SwiftUI

@main
struct DemoTimeAITFastApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

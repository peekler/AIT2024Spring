//
//  ContentView.swift
//  DemoTimeAITFast
//
//  Created by Peter Ekler on 05/02/2024.
//

import SwiftUI

struct ContentView: View {
    @State private var currentTime: String = ""
    
    var body: some View {
        VStack {
            
            Text("Hello, world! \(currentTime)")
            Button("Show time") {
                currentTime = "Current Time: \(Date().description)"
            }.buttonStyle(.borderedProminent)
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

//
//  BMICalculatorATIApp.swift
//  BMICalculatorATI
//
//  Created by Peter Ekler on 10/05/2024.
//

import SwiftUI

@main
struct BMICalculatorATIApp: App {
    var body: some Scene {
        WindowGroup {
            BMIView()
        }
    }
}

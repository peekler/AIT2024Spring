//
//  TODOAitSwiftUIApp.swift
//  TODOAitSwiftUI
//
//  Created by Peter Ekler on 10/05/2024.
//

import SwiftUI

@main
struct TODOAitSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                            TodoListView(viewModel: TodoListView.ViewModel(todos: []))
                        }
        }
    }
}

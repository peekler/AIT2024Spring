//
//  TodoItem.swift
//  TODOAitSwiftUI
//
//  Created by Peter Ekler on 10/05/2024.
//

import Foundation

struct TodoItem: Identifiable {
    var id: String
    var name: String
    var isChecked: Bool
}

//
//  TodoItem.swift
//  TodoApp
//
//  Created by Peter Ekler on 2023. 05. 10..
//
import CoreData

//@objc(TodoItem)
//public class TodoItem: NSManagedObject {
//    @NSManaged public var id: String
//    @NSManaged public var name: String
//    @NSManaged public var isChecked: Bool
//}

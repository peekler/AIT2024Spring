//
//  TodoListView+ViewModel.swift
//  TodoApp
//
//  Created by Peter Ekler on 2023. 05. 10..
//
import SwiftUI
import CoreData

extension TodoListView {
    final class ViewModel: ObservableObject {
        
        @Published var todos: [TodoItem] = []
        @Published var todoName = ""
        
        private var viewContext: NSManagedObjectContext
        
        init() {
            self.viewContext = PersistenceController.shared.container.viewContext
            fetchTodos()
        }
        
        private func fetchTodos() {
            let request: NSFetchRequest<TodoItem> = TodoItem.fetchRequest() as! NSFetchRequest<TodoItem>

            do {
                todos = try viewContext.fetch(request) // Directly assign fetched results to todos
            } catch {
                print("Error fetching data: \(error)")
            }
        }
        
        func toggleIsChecked(for todoId: String, isChecked: Bool) {
            let request: NSFetchRequest<TodoItem> = TodoItem.fetchRequest() as! NSFetchRequest<TodoItem>
            request.predicate = NSPredicate(format: "id == %@", todoId)
            
            do {
                let results = try viewContext.fetch(request)
                if let todoToUpdate = results.first {
                    todoToUpdate.isChecked = isChecked
                    print("SAVED", isChecked)
                    try viewContext.save()
                }
            } catch {
                print("Error updating todo: \(error)")
            }
        }

        
        func addTodo() {
            let newTodo = TodoItem(context: viewContext)
            newTodo.id = UUID().uuidString
            newTodo.name = todoName
            newTodo.isChecked = false
            saveContext()
            todoName = ""
            fetchTodos()
        }
        
        func delete(at offsets: IndexSet) {
            offsets.map { todos[$0] }.forEach(viewContext.delete)
            saveContext()
            fetchTodos()
        }
        
        private func saveContext() {
            do {
                try viewContext.save()
            } catch {
                print("Error saving context: \(error)")
            }
        }
    }
}


//
//  CoreDataTestApp.swift
//  CoreDataTest
//
//  Created by Dominik Kosztolánczi on 06/05/2024.
//

import SwiftUI

@main
struct CoreDataTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

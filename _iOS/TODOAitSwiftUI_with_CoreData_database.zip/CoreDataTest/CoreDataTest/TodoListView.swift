//
//  TodoListView.swift
//  TodoApp
//
//  Created by Peter Ekler on 2023. 05. 10..
//

import SwiftUI

struct TodoListView: View {
    @State private var showingAlert = false
    
    @StateObject var viewModel: ViewModel
    
    var body: some View {
        List {
            ForEach(viewModel.todos, id: \.self) { todo in
                TodoItemView(todo: todo, toggle: viewModel.toggleIsChecked)
            }
            .onDelete(perform: viewModel.delete)
        }
        .listRowInsets(.none)
        .listStyle(.plain)
        .alert("Add Todo", isPresented: $showingAlert) {
            TextField("Enter todo description", text: $viewModel.todoName)
                .autocorrectionDisabled(true)
            Button("Add") {
                viewModel.addTodo()
                showingAlert.toggle()
            }
            Button("Cancel")
            {
                viewModel.todoName = ""
                showingAlert.toggle()
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    showingAlert.toggle()
                } label: {
                    Text("Add")
                }
            }
        }
    }
}

struct TodoListView_Previews: PreviewProvider {
    static var previews: some View {
        TodoListView(viewModel: .init())
    }
}

//
//  TodoItemView.swift
//  TodoApp
//
//  Created by Peter Ekler on 2023. 05. 10..
//

import SwiftUI

struct TodoItemView: View {
    var todo: TodoItem
    @State private var isChecked = false
    let toggle: (String, Bool) -> Void
    
    var body: some View {
        HStack {
            Text(todo.name ?? "")
            Spacer()
            Toggle("", isOn: $isChecked)
        }
        .padding(.horizontal)
        .padding(.vertical, 5)
        .onChange(of: isChecked) { _, newValue in
            toggle(todo.id!, isChecked)
        }
    }

    init(todo: TodoItem, toggle: @escaping (String, Bool) -> Void) {
        self.todo = todo
        self.isChecked = todo.isChecked
        self.toggle = toggle
    }
}

//
//  ContentView.swift
//  CoreDataTest
//
//  Created by Dominik Kosztolánczi on 06/05/2024.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext



    var body: some View {
        NavigationView {
            TodoListView(viewModel: TodoListView.ViewModel())
        }
    }
}

#Preview {
    ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}
